import csv

# Read the CSV file
csv_file_path = 'Resources/budget_data.csv'
with open(csv_file_path, 'r') as file:
    csv_reader = csv.reader(file)
    next(csv_reader)  # Skip the header row

    # Initial variables
    total_months = 0
    total_profit = 0
    previous_profit = None
    profit_changes = []
    max_increase = ['', 0]
    max_decrease = ['', 0]

    # Loop through each row in the CSV file
    for row in csv_reader:
        # Extract the month and profit from the row
        month = row[0]
        profit = int(row[1])

        # Count the total number of months
        total_months += 1

        # Calculate the total profit/loss
        total_profit += profit

        # Calculate the profit change from the previous month (excluding the first month)
        if previous_profit is not None:
            profit_change = profit - previous_profit
            profit_changes.append(profit_change)

            # Track the greatest increase and decrease in profits
            if profit_change > max_increase[1]:
                max_increase = [month, profit_change]
            if profit_change < max_decrease[1]:
                max_decrease = [month, profit_change]

        previous_profit = profit

    # Calculate the average change in profits
    average_change = sum(profit_changes) / len(profit_changes)

    # Print the analysis results to the terminal
    print("Financial Analysis")
    print("----------------------------")
    print(f"Total Months: {total_months}")
    print(f"Total: ${total_profit}")
    print(f"Average Change: ${round(average_change, 2)}")
    print(f"Greatest Increase in Profits: {max_increase[0]} (${max_increase[1]})")
    print(f"Greatest Decrease in Profits: {max_decrease[0]} (${max_decrease[1]})")

    # Export the analysis results to a text file
    output_file = "Analysis/budget_analysis.txt"
    with open(output_file, 'w') as file:
        file.write("Financial Analysis\n")
        file.write("----------------------------\n")
        file.write(f"Total Months: {total_months}\n")
        file.write(f"Total: ${total_profit}\n")
        file.write(f"Average Change: ${round(average_change, 2)}\n")
        file.write(f"Greatest Increase in Profits: {max_increase[0]} (${max_increase[1]})\n")
        file.write(f"Greatest Decrease in Profits: {max_decrease[0]} (${max_decrease[1]})\n")

    print(f"Analysis results exported to {output_file}")
