import csv

# Read the CSV file
csv_file_path = 'Resources/election_data.csv'
with open(csv_file_path, 'r') as file:
    csv_reader = csv.reader(file)
    next(csv_reader)  # Skip the header row

    # Initial variables
    total_votes = 0
    candidates = {}

    # Loop through each row in the CSV file
    for row in csv_reader:
        # Extract the candidate's name from the row
        candidate_name = row[2]

        # Count the total number of votes
        total_votes += 1

        # Count the votes for each candidate
        if candidate_name in candidates:
            candidates[candidate_name] += 1
        else:
            candidates[candidate_name] = 1

# Finiding the percentage of votes for each candidate
percentages = {}
for candidate, votes in candidates.items():
    percentage = (votes / total_votes) * 100
    percentages[candidate] = round(percentage, 3)

# Determine the winner based on popular vote
winner = max(candidates, key=candidates.get)

# Print the analysis results to the terminal
print("Election Results")
print("-------------------------")
print(f"Total Votes: {total_votes}")
print("-------------------------")
for candidate, votes in candidates.items():
    percentage = percentages[candidate]
    print(f"{candidate}: {percentage}% ({votes})")
print("-------------------------")
print(f"Winner: {winner}")
print("-------------------------")

# Export the analysis results to a text file
output_file = "Analysis/election_results.txt"
with open(output_file, 'w') as file:
    file.write("Election Results\n")
    file.write("-------------------------\n")
    file.write(f"Total Votes: {total_votes}\n")
    file.write("-------------------------\n")
    for candidate, votes in candidates.items():
        percentage = percentages[candidate]
        file.write(f"{candidate}: {percentage}% ({votes})\n")
    file.write("-------------------------\n")
    file.write(f"Winner: {winner}\n")
    file.write("-------------------------\n")

print(f"Analysis results exported to {output_file}")
